Config = {

    logs = {
		-------------------------	
		NameLogs = "Logs - Brinks",
		-------------------------
        Coffre = "WEBHOOK",
        CoffreArmes = "WEBHOOK",
        Boss = "WEBHOOK",
        AddMoney = "WEBHOOK",
        SacBillet = "WEBHOOK",
        -------------------------
	},

	Job = {
		AuthorizedVehicles = {
			{model = 'stockade', label = 'Brinks'}
		},

		Blips = {
			Zone = vector3(-11.49,-661.83,33.48),
			Name = "[ ~r~Privée ~s~] Brinks",
			Sprite = 431,
			Scale = 0.7,
			Color = 2,
		},

		Garage = vector3(0.42868885397911, -660.34405517578, 33.475250244141),
		SpawnCar = vector4(-19.47,-669.50,32.33, 185.84),
		RangerVeh = vector3(-5.32, -669.13, 32.33),
		Coffre = vector3(4.62, -656.60, 33.45),
		Vestiaire = vector3(11.80, -661.65, 33.44),
        Boss = vector3(10.196173667908,-668.15307617188,33.449295043945), 

        position = {
            [1] = {name = "Banque",x = 311.25, y = -283.15, z = 54.17},
            [2] = {name = "Banque",x = -353.64, y = -54.03, z = 49.03},
            [3] = {name = "Distributeur De Billets",x = -845.94, y = -341.08, z = 38.68},
            [4] = {name = "Distributeur De Billets",x = -717.61, y = -915.68, z = 19.21},
            [5] = {name = "Distributeur De Billets",x = 155.84, y = 6642.81, z = 31.60},
            [6] = {name = "Banque Du Nord",x = -103.70, y = 6477.60, z = 31.62},
            [7] = {name = "Distributeur De Billets",x = -95.36, y = 6457.04, z = 31.45},
            [8] = {name = "Superette",x = -717.44, y = -915.61, z = 19.21},
            [9] = {name = "Banque",x = -2957.76, y = 481.54, z = 15.69},
            [10] ={name = "Superette",x = -3040.88, y = 593.11, z = 7.90},
            [11] ={name = "Superette",x = -3240.84, y = 1008.55, z = 12.83},
            [12] ={name = "Distributeur De Billets",x = -3144.39, y = 1127.39, z = 20.85},
            [13] ={name = "La puerta",x = -386.91, y = 6046.13, z = 31.50}
        },

        BesoinDunSac = true,
        Bag = 45,
        PourboirePossible = math.random(10, 20), -- Pourboire
        CoefDistancePaye = 0.1, --Coeficient multiplicateur qui en fonction de la distance definit la paie
		StopMission = vector3(-19.68, -670.97, 32.33),
	},

    NPC = {
        {hash="s_m_m_armoured_02", position = vector4(1.53,-660.57,32.48,95.57)}, 
        {hash="s_m_m_bouncer_01", position = vector4(3304.3898925781,5184.7163085938,18.711406707764,68.03)}, 
    },

	Robbery = {
        AlertJob = {"police", "bcso"},
		Time = 15,
		AlertPolice = 5, -- en secondes
		Cooldown = 600000,
		Weapon = {
			["453432689"] = true --arme whitelist
		},
        PriceSellSac = math.random(14500, 15000),
        Resell = vector3(3303.9479980469,5184.9458007813,19.711418151855),
	},

	Tenue = {
        specials = {
            [0] = {
                label = "Reprendre sa tenue civil",
                minimum_grade = 0, -- grade minmum pour prendre la tenue
                variations = {male = {
                    ['bags_1'] = 0,['bags_2'] = 0,
                }, female = {
                    ['bags_1'] = 0,['bags_2'] = 0,
                }},
                onEquip = function()
                    ESX.TriggerServerCallback('esx_skin:getPlayerSkin', function(skin)
                        TriggerEvent('skinchanger:loadSkin', skin)
                    end)
                    SetPedArmour(PlayerPedId(), 0)
                end
            },
            [1] = {
                label = "Tenue de boulot",
                minimum_grade = 0, -- grade minmum pour prendre la tenue
                variations = {
                    male = {
                        ['bags_1'] = 45,['bags_2'] = 0,
                        ['tshirt_1'] = 39, ['tshirt_2'] = 0,
                        ['torso_1'] = 55, ['torso_2'] = 0,
                        ['arms'] = 30,
                        ['pants_1'] = 46, ['pants_2'] = 0,
                        ['shoes_1'] =25, ['shoes_2'] = 0,
                        ['mask_1'] = 0, ['mask_2'] = 0,
                        ['bproof_1'] = 0,
                        ['chain_1'] = 0,
                        ['helmet_1'] = -1, ['helmet_2'] = 0,
                    },
                    female = {
                        ['bags_1'] = 45,['bags_2'] = 0,
                        ['tshirt_1'] = 15,['tshirt_2'] = 2,
                        ['torso_1'] = 65, ['torso_2'] = 2,
                        ['arms'] = 36, ['arms_2'] = 0,
                        ['pants_1'] = 38, ['pants_2'] = 2,
                        ['shoes_1'] = 12, ['shoes_2'] = 6,
                        ['mask_1'] = 0, ['mask_2'] = 0,
                        ['bproof_1'] = 0,
                        ['chain_1'] = 0,
                        ['helmet_1'] = -1, ['helmet_2'] = 0,
                    }
                },
                onEquip = function()
					SetPedArmour(PlayerPedId(), 100)  
                end
            }
        }
	}
}

---@class _BrinksActivity
_BrinksActivity = {}

if IsDuplicityVersion() then 
    ESX = nil
    TriggerEvent("esx:getSharedObject", function(obj) ESX = obj end)
else
    ESX = nil
    PlayerData = {}
    Citizen.CreateThread(function()
        while ESX == nil do 
            TriggerEvent('esx:getSharedObject', function(lib) ESX = lib end)
            Citizen.Wait(100) 
        end
        
        while ESX.GetPlayerData().job == nil do
            Citizen.Wait(10)
        end
        
        ESX.PlayerData = ESX.GetPlayerData()
        end)
        
        RegisterNetEvent('esx:playerLoaded')
        AddEventHandler('esx:playerLoaded', function(xPlayer)
            ESX.PlayerData = xPlayer
        end)
        
        RegisterNetEvent('esx:setJob')
        AddEventHandler('esx:setJob', function(job)
            ESX.PlayerData.job = job
        end)
end