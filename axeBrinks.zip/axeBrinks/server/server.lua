local Token = math.random(999, 9999).."-BRINKS-"..math.random(999, 9999).."-FIVEDEV-"..math.random(999, 9999)

RegisterServerEvent('axeBrinks:RequestToken')
AddEventHandler('axeBrinks:RequestToken', function()
	local source = source
    TriggerClientEvent('axeBrinks:OnRequestToken', source, Token)
end)

function eLogsDiscord(message,url)
    local DiscordWebHook = url
    if message == nil or message == '' then return FALSE end
    PerformHttpRequest(DiscordWebHook, function(err, text, headers) end, 'POST', json.encode({username = Config.logs.NameLogs, content = message}), { ['Content-Type'] = 'application/json' })
end

RegisterServerEvent('axeBrinks:alertPolice')
AddEventHandler('axeBrinks:alertPolice', function(source, position) 
    local xPlayer = ESX.GetPlayerFromId(source)
    local xPlayers = ESX.GetPlayers()

    for i = 1, #xPlayers, 1 do
        local xPlayer = ESX.GetPlayerFromId(xPlayers[i])
        if xPlayer.job.name or xPlayer.job2.name == Config.Robbery.AlertJob then
			TriggerClientEvent("brinks:robberyAlert", xPlayers[i], position)
		end
	end
end)

RegisterServerEvent("axeBrinks:Annonce")
AddEventHandler("axeBrinks:Annonce", function(tk, open, close)
    local xPlayer = ESX.GetPlayerFromId(source)
    local xPlayers = ESX.GetPlayers()
	if (Token ~= tk) then
		DropPlayer(xPlayer.source, "Cheat")
		return
	end
    for i = 1, #xPlayers, 1 do
        local xPlayer = ESX.GetPlayerFromId(xPlayers[i])
		if open then 
        	TriggerClientEvent("esx:showAdvancedNotification", xPlayers[i], "~y~Brinks", "Annonce", "Le Brinks est désormais ~g~Ouvert", "CHAR_CHAT_CALL", 8)
		else
			TriggerClientEvent("esx:showAdvancedNotification", xPlayers[i], "~y~Brinks", "Annonce", "Le Brinks est désormais ~r~Fermé", "CHAR_CHAT_CALL", 8)
		end
	end
end)

RegisterServerEvent("axeBrinks:Perso")
AddEventHandler("axeBrinks:Perso", function(tk, msg)
    local xPlayer = ESX.GetPlayerFromId(source)
    local xPlayers = ESX.GetPlayers()
	if (Token ~= tk) then
		DropPlayer(xPlayer.source, "Cheat")
		return
	end
    for i = 1, #xPlayers, 1 do
        local xPlayer = ESX.GetPlayerFromId(xPlayers[i])
        TriggerClientEvent("esx:showAdvancedNotification", xPlayers[i], "~y~Brinks", "Annonce", msg, "CHAR_CHAT_CALL", 8)
    end
end)

--Livraison


RegisterServerEvent('axeBrinks:pourboire') --pourboire eventuel
AddEventHandler('axeBrinks:pourboire', function(tk, pourboire)
	local _source = source
	local xPlayer = ESX.GetPlayerFromId(_source)
	if (Token ~= tk) then
		DropPlayer(xPlayer.source, "Cheat")
		return
	end
	xPlayer.addMoney(pourboire)
	eLogsDiscord("[AddMoney-Brinks] "..xPlayer.getName().." viens de gagner "..pourboire.."$ en pourboire de mission", Config.logs.AddMoney)
end)

RegisterServerEvent('axeBrinks:paie') --paie a la livraison
AddEventHandler('axeBrinks:paie', function(tk, paie)
	local _source = source
	local xPlayer = ESX.GetPlayerFromId(_source)
	if (Token ~= tk) then
		DropPlayer(xPlayer.source, "Cheat")
		return
	end
	xPlayer.addMoney(paie)
	eLogsDiscord("[AddMoney-Brinks] "..xPlayer.getName().." viens de gagner "..paie.."$ pour avoir livrer un sac mission", Config.logs.AddMoney)
end)

RegisterServerEvent('axeBrinks:paiemoins') --quand il a pas le brinks
AddEventHandler('axeBrinks:paiemoins', function(tk)
	local _source = source
	local xPlayer = ESX.GetPlayerFromId(_source)
	if (Token ~= tk) then
		DropPlayer(xPlayer.source, "Cheat")
		return
	end
	xPlayer.removeMoney("300")
end)

RegisterServerEvent("axeBrinks:paiefinale") --Paie "bonus" lors de la fin de service
AddEventHandler("axeBrinks:paiefinale", function(tk)
	local _source = source
	local xPlayer = ESX.GetPlayerFromId(_source)

	local societyAccount = nil

	local flouzefin = math.random(50, 200)

	local flouzefin2 = math.random(200, 500)

	if (Token ~= tk) then
		DropPlayer(xPlayer.source, "Cheat")
		return
	end

	xPlayer.addMoney(flouzefin)
	eLogsDiscord("[AddMoney-Brinks] "..xPlayer.getName().." viens de gagner "..flouzefin.."$ pour avoir terminer c'est missions", Config.logs.AddMoney)

	TriggerEvent('esx_addonaccount:getSharedAccount', 'society_brinks', function(account) -- remplacer brinks par le nom du metier voulu (si désiré)
		societyAccount = account
	end)

	if societyAccount ~= nil then
		societyAccount.addMoney(flouzefin2)
		eLogsDiscord("[Boss-Brinks] La société viens de gagner "..flouzefin2.."$ grâce à "..xPlayer.getName(), Config.logs.Boss)
	end

	TriggerClientEvent('esx:showNotification', source, "~h~~g~Voici votre petit bonus final : ~w~" .. flouzefin .. "~b~ $")
end)

RegisterServerEvent("axeBrinks:itemadd") --Ajout temporaire de l'item "sacbillets"
AddEventHandler("axeBrinks:itemadd", function(tk, nbaxelivraison)
	local _source = source
	local xPlayer = ESX.GetPlayerFromId(_source)

	if (Token ~= tk) then
		DropPlayer(xPlayer.source, "Cheat")
		return
	end

	xPlayer.addInventoryItem('sacbillets', tonumber(nbaxelivraison))
	eLogsDiscord("[Sac-Billet-Brinks] "..xPlayer.getName().. " viens de reçevoir "..nbaxelivraison.. " sac de billet pour faire des missions.", Config.logs.SacBillet)
end)

RegisterServerEvent("axeBrinks:itemrm") --Rm de l'item "sacbillets"
AddEventHandler("axeBrinks:itemrm", function(tk)
	local _source = source
	local xPlayer = ESX.GetPlayerFromId(_source)

	if (Token ~= tk) then
		DropPlayer(xPlayer.source, "Cheat")
		return
	end

	xPlayer.removeInventoryItem('sacbillets', 1)
	eLogsDiscord("[Sac-Billet-Brinks] "..xPlayer.getName().. " viens de finir une mission -1 sac à billet.", Config.logs.SacBillet)
end)

RegisterServerEvent("axeBrinks:resell") 
AddEventHandler("axeBrinks:resell", function(tk)
	local _source = source
	local xPlayer = ESX.GetPlayerFromId(_source)
	if (Token ~= tk) then
		DropPlayer(xPlayer.source, "Cheat")
		return
	end
	xPlayer.removeInventoryItem('sacbillets', 1)
	xPlayer.addAccountMoney("black_money", Config.Robbery.PriceSellSac)
	TriggerClientEvent("esx:showNotification", _source, "Vous avez échanger un sac contre ~r~"..Config.Robbery.PriceSellSac.." $")
	eLogsDiscord("[Sac-Billet-Brinks] "..xPlayer.getName().. " viens de vendre 1 sac surement obtenue en braquage.", Config.logs.SacBillet)
end)

RegisterServerEvent("axeBrinks:deleteAllPlats") --Rm de l'item "sacbillets"
AddEventHandler("axeBrinks:deleteAllPlats", function(tk)
	local _source = source
	local xPlayer = ESX.GetPlayerFromId(_source)
		
	local platsnbr = xPlayer.getInventoryItem('sacbillets').count
	if (Token ~= tk) then
		DropPlayer(xPlayer.source, "Cheat")
		return
	end
	xPlayer.removeInventoryItem('sacbillets', platsnbr)
	eLogsDiscord("[Sac-Billet-Brinks] "..xPlayer.getName().. " viens d'arrêter les missions et a rendu "..platsnbr.." sac de billet.", Config.logs.SacBillet)
end)


RegisterServerEvent('axeBrinks:recruter')
AddEventHandler('axeBrinks:recruter', function(tk,target)
  local xPlayer = ESX.GetPlayerFromId(source)
  local xTarget = ESX.GetPlayerFromId(target)
	if (Token ~= tk) then
		DropPlayer(xPlayer.source, "Cheat")
		return
	end
  	if xPlayer.job.grade_name == 'boss' then
		xTarget.setJob(Config.OrgaName, 0)
		TriggerClientEvent('esx:showNotification', xPlayer.source, "~g~Le joueur a bien été recruté")
		TriggerClientEvent('esx:showNotification', target, "<C>Bienvenue!")
		eLogsDiscord("[Actions-Patron] **"..xPlayer.getName().."** a recruté **"..xTarget.getName().."**", Config.logs.Boss)
  	else
        TriggerClientEvent('esx:showNotification', xPlayer.source, "[~r~Problème~s~]\nVous n'êtes pas patron")
	end
end)

RegisterServerEvent('axeBrinks:promouvoir')
AddEventHandler('axeBrinks:promouvoir', function(tk, target)
  local xPlayer = ESX.GetPlayerFromId(source)
  local xTarget = ESX.GetPlayerFromId(target)
	if (Token ~= tk) then
		DropPlayer(xPlayer.source, "Cheat")
		return
	end
  	if xPlayer.job.grade_name == 'boss' and xPlayer.job.name == xTarget.job.name then
		xTarget.setJob(Config.OrgaName, tonumber(xTarget.job.grade) + 1)
		TriggerClientEvent('esx:showNotification', xPlayer.source, "~g~Le joueur a bien été promu")
		TriggerClientEvent('esx:showNotification', target, "~g~Vous avez été promu!")
		eLogsDiscord("[Actions-Patron] **"..xPlayer.getName().."** a promu **"..xTarget.getName().."**", Config.logs.Boss)
  	else
        TriggerClientEvent('esx:showNotification', xPlayer.source, "[~r~Problème~s~]\nVous n'êtes pas patron ou le joueur ne peux être promu")
	end
end)

RegisterServerEvent('axeBrinks:descendre')
AddEventHandler('axeBrinks:descendre', function(tk, target)
  local xPlayer = ESX.GetPlayerFromId(source)
  local xTarget = ESX.GetPlayerFromId(target)
	if (Token ~= tk) then
		DropPlayer(xPlayer.source, "Cheat")
		return
	end
	if xPlayer.job.grade_name == 'boss' and xPlayer.job.name == xTarget.job.name then
		xTarget.setJob(Config.OrgaName, tonumber(xTarget.job.grade) - 1)
		TriggerClientEvent('esx:showNotification', xPlayer.source, "~o~Le joueur a bien été rétrograder")
		TriggerClientEvent('esx:showNotification', target, "~o~Vous avez été rétrogradé!")
		eLogsDiscord("[Actions-Patron] **"..xPlayer.getName().."** a rétrogradé **"..xTarget.getName().."**", Config.logs.Boss)
	else
		TriggerClientEvent('esx:showNotification', xPlayer.source, "[~r~Problème~s~]\nVous n'êtes pas patron ou le joueur ne peux être descendu plus")
	end
end)

RegisterServerEvent('axeBrinks:virer')
AddEventHandler('axeBrinks:virer', function(tk, target)
  local xPlayer = ESX.GetPlayerFromId(source)
  local xTarget = ESX.GetPlayerFromId(target)
	if (Token ~= tk) then
		DropPlayer(xPlayer.source, "Cheat")
		return
	end
	if xPlayer.job.grade_name == 'boss' and xPlayer.job.name == xTarget.job.name then
		xTarget.setJob("unemployed", 0)
		TriggerClientEvent('esx:showNotification', xPlayer.source, "~o~Le joueur a bien été destituer")
		TriggerClientEvent('esx:showNotification', target, "Vous avez été viré!")
		eLogsDiscord("[Actions-Patron] **"..xPlayer.getName().."** a viré **"..xTarget.getName().."**", Config.logs.Boss)
	else
		TriggerClientEvent('esx:showNotification', xPlayer.source, "[~r~Problème~s~]\nVous n'êtes pas patron ou le joueur ne peux être destituer")
	end
end)

RegisterServerEvent("axeBrinks:retraitentreprise")
AddEventHandler("axeBrinks:retraitentreprise", function(tk, money)
	local _source = source
	local xPlayer = ESX.GetPlayerFromId(_source)
	local total = money
	local xMoney = xPlayer.getAccount("bank").money
	if (Token ~= tk) then
		DropPlayer(xPlayer.source, "Cheat")
		return
	end
    TriggerEvent('esx_addonaccount:getSharedAccount', "society_brinks", function (account)
		if account.money >= total then
			account.removeMoney(total)
			xPlayer.addAccountMoney('bank', total)
			TriggerClientEvent('esx:showAdvancedNotification', source, '~g~Banque', 'Information', "~g~Vous avez retiré "..total.." $", 'CHAR_BANK', 8)
            eLogsDiscord("[Actions-Patron] **"..xPlayer.getName().."** a retirer **"..total.."** de l'entreprise", Config.logs.Boss)
		else
            TriggerClientEvent('esx:showNotification', source, "[~r~Problème~s~]\nVous n'avez pas assez d'argent dans votre entreprise")
		end
	end)
end) 
  
RegisterServerEvent("axeBrinks:depotentreprise")
AddEventHandler("axeBrinks:depotentreprise", function(tk, money)
    local _source = source
    local xPlayer = ESX.GetPlayerFromId(_source)
    local total = money
    local xMoney = xPlayer.getMoney()
    
	if (Token ~= tk) then
		DropPlayer(xPlayer.source, "Cheat")
		return
	end

    TriggerEvent('esx_addonaccount:getSharedAccount', "society_brinks", function (account)
        if xMoney >= total then
            account.addMoney(total)
            xPlayer.removeAccountMoney('bank', total)
			TriggerClientEvent('esx:showAdvancedNotification', source, '~g~Banque', 'Information', "~g~Vous avez déposé "..total.." $", 'CHAR_BANK', 8)
            eLogsDiscord("[Actions-Patron] **"..xPlayer.getName().."** a déposer **"..total.."** de l'entreprise", Config.logs.Boss)
        else
            TriggerClientEvent('esx:showNotification', source, "[~r~Problème~s~]\nVous n'avez pas assez d'argent")
        end
    end)   
end)

ESX.RegisterServerCallback('axeBrinks:getSocietyMoney', function(source, cb, societyName)
	if societyName ~= nil then
	  local society = "society_brinks"
	  TriggerEvent('esx_addonaccount:getSharedAccount', "society_brinks", function(account)
		cb(account.money)
	  end)
	else
	  cb(0)
	end
end)

ESX.RegisterServerCallback('axeBrinks:getStockItems', function(source, cb)
	TriggerEvent('esx_addoninventory:getSharedInventory', 'society_brinks', function(inventory)
		cb(inventory.items)
	end)
end)

RegisterNetEvent('axeBrinks:getStockItem')
AddEventHandler('axeBrinks:getStockItem', function(tk, itemName, count)
	local _source = source
	local xPlayer = ESX.GetPlayerFromId(_source)
	if (Token ~= tk) then
		DropPlayer(xPlayer.source, "Cheat")
		return
	end
	TriggerEvent('esx_addoninventory:getSharedInventory', 'society_brinks', function(inventory)
		local inventoryItem = inventory.getItem(itemName)

		-- is there enough in the society?
		if count > 0 and inventoryItem.count >= count then
				inventory.removeItem(itemName, count)
				xPlayer.addInventoryItem(itemName, count)
				TriggerClientEvent('esx:showNotification', _source, 'Objet retiré ', count, inventoryItem.label)
				eLogsDiscord("[Coffre-Brinks] "..xPlayer.getName().." a retiré "..count.." "..inventoryItem.label.." du coffre Brinks", Config.logs.Coffre)
		else
			TriggerClientEvent('esx:showNotification', _source, "Quantité invalide")
		end
	end)
end)

ESX.RegisterServerCallback('axeBrinks:getPlayerInventory', function(source, cb)
	local xPlayer = ESX.GetPlayerFromId(source)
	local items   = xPlayer.inventory

	cb({items = items})
end)

RegisterNetEvent('axeBrinks:putStockItems')
AddEventHandler('axeBrinks:putStockItems', function(tk, itemName, count)
	local _source = source
	local xPlayer = ESX.GetPlayerFromId(_source)
	local sourceItem = xPlayer.getInventoryItem(itemName)
	if (Token ~= tk) then
		DropPlayer(xPlayer.source, "Cheat")
		return
	end
	TriggerEvent('esx_addoninventory:getSharedInventory', 'society_brinks', function(inventory)
		local inventoryItem = inventory.getItem(itemName)

		-- does the player have enough of the item?
		if sourceItem.count >= count and count > 0 then
			xPlayer.removeInventoryItem(itemName, count)
			inventory.addItem(itemName, count)
			TriggerClientEvent('esx:showNotification', _source, 'Objet Déposé ', count, inventoryItem.label)
			eLogsDiscord("[Coffre-Brinks] "..xPlayer.getName().." a déposé "..count.." "..inventoryItem.label.." dans le coffre Brinks", Config.logs.Coffre)
		else
			TriggerClientEvent('esx:showNotification', _source, "Quantité invalide")
		end
	end)
end)

ESX.RegisterServerCallback('axeBrinks:getArmoryWeapons', function(source, cb)
	TriggerEvent('esx_datastore:getSharedDataStore', "society_brinks", function(store)
		local weapons = store.get('weapons')

		if weapons == nil then
			weapons = {}
		end
		cb(weapons)
	end)
end)

ESX.RegisterServerCallback('axeBrinks:ddArmoryWeapon', function(source, cb, weaponName, removeWeapon)
	local xPlayer = ESX.GetPlayerFromId(source)

	if removeWeapon then
		xPlayer.removeWeapon(weaponName)
		eLogsDiscord("[Coffre-Brinks] "..xPlayer.getName().." a déposé "..weaponName.." du coffre", Config.logs.Coffre)
	end

	TriggerEvent('esx_datastore:getSharedDataStore', "society_brinks", function(store)
		local weapons = store.get('weapons') or {}
		local foundWeapon = false

		for i=1, #weapons, 1 do
			if weapons[i].name == weaponName then
				weapons[i].count = weapons[i].count + 1
				foundWeapon = true
				break
			end
		end

		if not foundWeapon then
			table.insert(weapons, {
				name  = weaponName,
				count = 1
			})
		end

		store.set('weapons', weapons)
		cb()
	end)
end)

ESX.RegisterServerCallback('axeBrinks:removeArmoryWeapon', function(source, cb, weaponName)
	local xPlayer = ESX.GetPlayerFromId(source)
	xPlayer.addWeapon(weaponName, 0)
	eLogsDiscord("[Coffre-Brinks] "..xPlayer.getName().." a retiré "..weaponName.." du coffre", Config.logs.Coffre)

	TriggerEvent('esx_datastore:getSharedDataStore', "society_brinks", function(store)
		local weapons = store.get('weapons') or {}

		local foundWeapon = false

		for i=1, #weapons, 1 do
			if weapons[i].name == weaponName then
				weapons[i].count = (weapons[i].count > 0 and weapons[i].count - 1 or 0)
				foundWeapon = true
				break
			end
		end

		if not foundWeapon then
			table.insert(weapons, {
				name = weaponName,
				count = 0
			})
		end

		store.set('weapons', weapons)
		cb()
	end)
end)