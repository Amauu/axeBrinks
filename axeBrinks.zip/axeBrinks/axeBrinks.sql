INSERT INTO `addon_account` (name, label, shared) VALUES
	('society_brinks', 'Brinks', 1)
;

INSERT INTO `addon_inventory` (name, label, shared) VALUES
	('society_brinks', 'Brinks', 1)
;

INSERT INTO `datastore` (name, label, shared) VALUES 
	('society_brinks','Brinks', 1)
;

INSERT INTO `jobs` (name, label) VALUES
	('brinks', 'Brinks')
;

INSERT INTO `job_grades` (job_name, grade, name, label, salary, skin_male, skin_female) VALUES
	('brinks', 0, 'novice', 'Convoyeur Brink’s', 100, '{}', '{}'),
	('brinks', 1, 'experimente', 'Chef de mouvement Brink’s', 100, '{}', '{}'),
	('brinks', 2, 'ce', 'Chef d’agence Brink’s', 100, '{}', '{}'),
	('brinks', 3, 'cpdg', 'CO-PDG', 100, '{}', '{}'),
	('brinks', 4, 'boss', 'Patron', 100, '{}', '{}')
;


INSERT INTO `items` (name, label) VALUES
	('sacbillets', 'Sac De Billets') 
;