function ResellMenu()
    local main = RageUI.CreateMenu('', '~r~Reseller')

        RageUI.Visible(main, not RageUI.Visible(main))

        while main do
        Citizen.Wait(0)        

        RageUI.IsVisible(main, true, true, true, function()

            if ESX.PlayerData.job and ESX.PlayerData.job.name == "police" or ESX.PlayerData.job and ESX.PlayerData.job.name == "brinks" then
                RageUI.ButtonWithStyle("→ Faire un échange", "~r~Votre métier ne permet pas l'échange", {RightLabel = "~r~1-Sac / 15.000$"}, false, function(Hovered, Active, Selected)
                end)
            else
                RageUI.ButtonWithStyle("→ Faire un échange", nil, {RightLabel = "~r~1-Sac / 15.000$"}, not cooldown, function(Hovered, Active, Selected)
                    if Selected then
                        _TriggerServerEvent("axeBrinks:resell")
                        cooldownMenu(1000)
                    end
                end)
            end

            end, function()
            end)

            if not RageUI.Visible(main) then
            main = RMenu:DeleteType("main", true)
        end
    end
end