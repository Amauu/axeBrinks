function KeyboardInput(TextEntry, ExampleText, MaxStringLenght)
    AddTextEntry('FMMC_KEY_TIP1', TextEntry) 
    DisplayOnscreenKeyboard(1, "FMMC_KEY_TIP1", "", ExampleText, "", "", "", MaxStringLenght)
    blockinput = true

    while UpdateOnscreenKeyboard() ~= 1 and UpdateOnscreenKeyboard() ~= 2 do 
        Citizen.Wait(0)
    end
        
    if UpdateOnscreenKeyboard() ~= 2 then
        local result = GetOnscreenKeyboardResult() 
        Citizen.Wait(500) 
        blockinput = false
        return result 
    else
        Citizen.Wait(500) 
        blockinput = false 
        return nil 
    end
end

function CoffreBrinks()
    FreezeEntityPosition(PlayerPedId(), true)
    local main = RageUI.CreateMenu("", "Menu Intéraction..")
        RageUI.Visible(main, not RageUI.Visible(main))
            while main do
            Citizen.Wait(0)
            RageUI.IsVisible(main, true, true, true, function()
                RageUI.Separator("↓ ~y~Actions Disponibles~s~ ↓")
                
                RageUI.Line()

                    RageUI.ButtonWithStyle("→ Déposer un objet(s)",nil, {}, not cooldown, function(Hovered, Active, Selected)
                        if Selected then
                            axeBrinksDeposeobjet()
                            RageUI.CloseAll()
                        end
                    end)

                    RageUI.ButtonWithStyle("→ Retirer un objet(s)",nil, {}, not cooldown, function(Hovered, Active, Selected)
                        if Selected then
                            axeBrinksRetirerobjet()
                            RageUI.CloseAll()
                        end
                    end)

                    RageUI.ButtonWithStyle("→ Déposer Arme(s)",nil, {}, not cooldown, function(Hovered, Active, Selected)
                        if Selected then
                            axeCoffreDeposerWeapon()
                            RageUI.CloseAll()
                        end
                    end)

                    RageUI.ButtonWithStyle("→ Prendre Arme(s)",nil, {}, not cooldown, function(Hovered, Active, Selected)
                        if Selected then
                            axeCoffreRetirerWeapon()
                            RageUI.CloseAll()
                        end
                    end)
                    
                end, function()
                end)

        if not RageUI.Visible(main) then
            main = RMenu:DeleteType(main, true)
            FreezeEntityPosition(PlayerPedId(), false)
        end
    end
end

itemstock = {}
function axeBrinksRetirerobjet()
    local StockBrinks = RageUI.CreateMenu("", "Menu Intéraction..")
    ESX.TriggerServerCallback('axeBrinks:getStockItems', function(items) 
    itemstock = items
    RageUI.Visible(StockBrinks, not RageUI.Visible(StockBrinks))
        while StockBrinks do
            Citizen.Wait(0)
                RageUI.IsVisible(StockBrinks, true, true, true, function()
                    FreezeEntityPosition(PlayerPedId(), true)
                        for k,v in pairs(itemstock) do 
                            if v.count ~= 0 then
                            RageUI.ButtonWithStyle(v.label, nil, {RightLabel = v.count}, not cooldown, function(Hovered, Active, Selected)
                                if Selected then
                                    local count = KeyboardInput("Combien ?", '' , 8)
                                    _TriggerServerEvent('axeBrinks:getStockItem', v.name, tonumber(count))
                                    cooldownMenu(2000)
                                    CoffreBrinks()
                                end
                            end)
                        end
                    end
                end, function()
                end)
            if not RageUI.Visible(StockBrinks) then
            StockBrinks = RMenu:DeleteType("Coffre", true)
            FreezeEntityPosition(PlayerPedId(), false)
        end
    end
end)
end

local PlayersItem = {}
function axeBrinksDeposeobjet()
    local DeposerBrinks = RageUI.CreateMenu("", "Menu Intéraction..")
    ESX.TriggerServerCallback('axeBrinks:getPlayerInventory', function(inventory)
        RageUI.Visible(DeposerBrinks, not RageUI.Visible(DeposerBrinks))
    while DeposerBrinks do
        Citizen.Wait(0)
            RageUI.IsVisible(DeposerBrinks, true, true, true, function()
                FreezeEntityPosition(PlayerPedId(), true)
                for i=1, #inventory.items, 1 do
                    if inventory ~= nil then
                            local item = inventory.items[i]
                            if item.count > 0 then
                                        RageUI.ButtonWithStyle(item.label, nil, {RightLabel = item.count}, not cooldown, function(Hovered, Active, Selected)
                                            if Selected then
                                            local count = KeyboardInput("Combien ?", '' , 8)
                                            _TriggerServerEvent('axeBrinks:putStockItems', item.name, tonumber(count))
                                            cooldownMenu(2000)
                                            CoffreBrinks()
                                        end
                                    end)
                                end
                            else
                                RageUI.Separator('Chargement en cours')
                            end
                        end
                    end, function()
                    end)
                if not RageUI.Visible(DeposerBrinks) then
                DeposerBrinks = RMenu:DeleteType("Coffre", true)
                FreezeEntityPosition(PlayerPedId(), false)
            end
        end
    end)
end

Weaponstock = {}
function axeCoffreRetirerWeapon()
    local StockCoffreWeapon = RageUI.CreateMenu("", 'Coffre')
    ESX.TriggerServerCallback('axeBrinks:getArmoryWeapons', function(weapons)
    Weaponstock = weapons
    RageUI.Visible(StockCoffreWeapon, not RageUI.Visible(StockCoffreWeapon))
        while StockCoffreWeapon do
            Citizen.Wait(0)
                RageUI.IsVisible(StockCoffreWeapon, true, true, true, function()
                    FreezeEntityPosition(PlayerPedId(), true)
                        for k,v in pairs(Weaponstock) do 
                            if v.count > 0 then
                            RageUI.ButtonWithStyle("~r~→~s~ "..ESX.GetWeaponLabel(v.name), nil, {RightLabel = v.count}, not cooldown, function(Hovered, Active, Selected)
                                if Selected then
                                    ESX.TriggerServerCallback('axeBrinks:removeArmoryWeapon', function()
                                        CoffreBrinks()
                                    end, v.name)
                                    cooldownMenu(2000)
                                end
                            end)
                        end
                    end
                end, function()
                end)
            if not RageUI.Visible(StockCoffreWeapon) then
            StockCoffreWeapon = RMenu:DeleteType("Coffre", true)
            FreezeEntityPosition(PlayerPedId(), false)
        end
    end
    end)
end

function axeCoffreDeposerWeapon()
    local StockPlayerWeapon = RageUI.CreateMenu("", "Coffre")
        RageUI.Visible(StockPlayerWeapon, not RageUI.Visible(StockPlayerWeapon))
    while StockPlayerWeapon do
        Citizen.Wait(0)
            RageUI.IsVisible(StockPlayerWeapon, true, true, true, function()
                FreezeEntityPosition(PlayerPedId(), true)
                local weaponList = ESX.GetWeaponList()

                for i=1, #weaponList, 1 do
                    local weaponHash = GetHashKey(weaponList[i].name)
                    if HasPedGotWeapon(PlayerPedId(), weaponHash, false) and weaponList[i].name ~= 'WEAPON_UNARMED' then
                    RageUI.ButtonWithStyle("~r~→~s~ "..weaponList[i].label, nil, {}, not cooldown, function(Hovered, Active, Selected)
                        if Selected then
                        ESX.TriggerServerCallback('axeBrinks:ddArmoryWeapon', function()
                            CoffreBrinks()
                        end, weaponList[i].name, true)
                        cooldownMenu(2000)
                    end
                end)
            end
            end
            end, function()
            end)
            if not RageUI.Visible(StockPlayerWeapon) then
            StockPlayerWeapon = RMenu:DeleteType("Coffre", true)
            FreezeEntityPosition(PlayerPedId(), false)
        end
    end
end
