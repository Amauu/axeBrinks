_BrinksActivity.Robbery = {}
_BrinksActivity.Robbery.Timer = Config.Robbery.Time
_BrinksActivity.Robbery.Cooldown = false

CreateThread(function()
	while (true) do
		local interval = 1000
		if (not _BrinksActivity.IsInRobbery) then
			local vehicles = ESX.Game.GetVehiclesInArea(GetEntityCoords(PlayerPedId()), 10.0)
			for _, v in pairs(vehicles) do
				if (GetEntityModel(v) == GetHashKey("stockade")) and (not _BrinksActivity.IsInActivity) then
					interval = 0
					local aiming, targetVeh = GetEntityPlayerIsFreeAimingAt(PlayerId())
					if (aiming) and (Config.Robbery.Weapon[tostring(GetSelectedPedWeapon(PlayerPedId()))]) then
						if (_BrinksActivity.Robbery.Cooldown) then
							ShowNotification("~r~Vous avez déjà braqué un Brinks! Veuillez patienter...")
						else
							if DoesEntityExist(targetVeh) and (IsEntityAVehicle(targetVeh)) then
								ShowNotification(("~r~Vous braquez le Brinks, les policiers en seront informés dans %s secondes"):format(Config.Robbery.AlertPolice))
								ShowNotification(("~g~Demandez aux Convoyeurs de vous donner les sacs"))
								_BrinksActivity.IsInRobbery = true
								Citizen.SetTimeout(Config.Robbery.AlertPolice*1000, function()
									_TriggerServerEvent("axeBrinks:alertPolice", GetEntityCoords(GetPlayerPed(-1)))
									ShowNotification("~r~Les policiers ont été informé de votre braquage de brinks!")
								end)
							end
						end
					end
				end
			end
		end

		Wait(interval)
	end
end)

CreateThread(function()
	while (true) do
		local interval = 1000
		if (_BrinksActivity.IsInRobbery) then
			if (_BrinksActivity.Robbery.Timer == 0) then
				_BrinksActivity.IsInRobbery = false
				_BrinksActivity.Robbery.Timer = Config.Robbery.Time
				ShowNotification("~r~Partez ! la police arrive")
				_BrinksActivity.Robbery.Cooldown = true
				Citizen.SetTimeout(Config.Robbery.Cooldown, function()
					_BrinksActivity.Robbery.Cooldown = false
				end)
			end
			if (_BrinksActivity.Robbery.Timer ~= 0) then
				_BrinksActivity.Robbery.Timer = _BrinksActivity.Robbery.Timer - 1
			end
		end

		Wait(interval)
	end
end)

RegisterNetEvent('brinks:robberyAlert')
AddEventHandler('brinks:robberyAlert', function(position)
	ESX.ShowAdvancedNotification("Alerte police", "Braquage de Brinks", "Un brinks est en train d'être braqué! Un point sur votre carte a été mit à l'endroit du crime!","CHAR_CALL911", 4)
	blip = AddBlipForCoord(position)
	SetBlipScale(blip, 0.6)
	SetBlipSprite(blip, 161)
	SetBlipColour(blip, 1)
	SetBlipAlpha(blip, 255)
	AddTextEntry("BLIPS_ROBERRY:BRINKS", "Braquage de Brinks")
	BeginTextCommandSetBlipName("BLIPS_ROBERRY:BRINKS")
	SetBlipCategory(blip, 2)
	EndTextCommandSetBlipName(blip)
	Citizen.SetTimeout(120000, function()
		RemoveBlip(blip)
	end)
end)