local coefflouze, pourboire, nbaxelivraison, position, isInJobLIVR, livr, isToHouse, isToaxelivraison, paie, posibilidad, px, py, pz = Config.Job.CoefDistancePaye, Config.Job.PourboirePossible, 0, Config.Job.position, false, 0, 0, false, 0, 0, 0, 0, 0

function StartBliper(position,nbMission)
	Blip = AddBlipForCoord(position[nbMission].x, position[nbMission].y, position[nbMission].z)
	SetBlipSprite(Blip, 1)
  SetBlipColour(Blip, 2)
	SetBlipRoute(Blip, true)
end

function round(num, numDecimalPlaces)
  local mult = 5^(numDecimalPlaces or 0)
  return math.floor(num * mult + 0.5) / mult
end

function deleteCar( entity )
  Citizen.InvokeNative( 0xEA386986E786A54F, Citizen.PointerValueIntInitialized( entity ) ) --Native qui supprime le vehicule
end

function IsInVehicle() --Fonction de verification du joueur sur le vehicule
    local ply = GetPlayerPed(-1)
    if IsPedSittingInAnyVehicle(ply) then
      return true
    else
      return false
    end
end

function IsInAuthorizedVehicle()
    local playerPed = PlayerPedId()
    local vehModel  = GetEntityModel(GetVehiclePedIsIn(playerPed, false))

    for i=1, #Config.Job.AuthorizedVehicles, 1 do
      if vehModel == GetHashKey(Config.Job.AuthorizedVehicles[i].model) then
        return true
      end
    end
    
    return false
end

function StartMission()
    ped = GetPlayerPed(-1)
    playerCoords = GetEntityCoords(ped)
    notif = true
    isInJobLIVR = true
    isToHouse = true
    nbMission = math.random(1, 13)
    px = position[nbMission].x
    py = position[nbMission].y
    pz = position[nbMission].z
    distance = round(GetDistanceBetweenCoords(playerCoords, px,py,pz))
    paie = distance * coefflouze
    StartBliper(position,nbMission)
    nbaxelivraison = math.random(40, 80)
    _TriggerServerEvent("axeBrinks:itemadd", nbaxelivraison)
end

function StopMission()
    RemoveBlip(Blip)
    _TriggerServerEvent('axeBrinks:deleteAllPlats')
    MissionJob = UnChecked
    isInJobLIVR = false
    livr = 0
    isToHouse = false
    isToaxelivraison = false
    paie = 0
    px = 0
    py = 0
    pz = 0
end

local sac = nil

CreateThread(function()
    while true do
      Wait(1000)
        TriggerEvent('skinchanger:getSkin', function(skin)
          sac = skin['bags_1']
        end)
      Wait(1000)
    end
end)

CreateThread(function() 
  while true do

    local WaitBro = 350

      if isToHouse == true then

        WaitBro = 0

        destinol = position[nbMission].name

        while notif == true do

          ShowNotification("~g~Direction : ~w~" ..destinol.. " ~g~pour livrer les sacs de billets")
          notif = false

          i = 1
        end
        
        DrawMarker(22, position[nbMission].x,position[nbMission].y,position[nbMission].z, 0, 0, 0, 90, 0, 0, 0.3, 0.3, 0.3,255,215,0, 200, 255, 255, 255, 255)

        if GetDistanceBetweenCoords(px,py,pz, GetEntityCoords(GetPlayerPed(-1),true)) < 3 then


          ShowHelpNotification("Appuyez sur ~INPUT_CONTEXT~ pour livrer les sacs de billets",0,1,0.6,0.6,0.6,255,255,255,255)


          if Config.Job.BesoinDunSac then
              if IsControlJustPressed(1,38) then
                  if sac == 45 then
                    notif2 = true
                    posibilidad = math.random(1, 100)
                    afaitunplatmin = true
                    _TriggerServerEvent("axeBrinks:itemrm")
                    nbaxelivraison = nbaxelivraison - 1
                    ShowNotification("~g~Voici votre argent, merci au revoir ! ~w~" .. paie .. "~b~ $")
                    _TriggerServerEvent("axeBrinks:paie", paie)
                      if (posibilidad > 70) and (posibilidad < 90) then
        
                        ShowNotification("~g~Un petit pourboire : ~w~" .. pourboire .. "~b~ $")
        
                        _TriggerServerEvent("axeBrinks:pourboire", pourboire)
        
                      end
                    RemoveBlip(Blip)
                    Wait(250)
                      if nbaxelivraison == 0 then
                        isToHouse = false
                        isToaxelivraison = true
                      else
                        isToHouse = true
                        isToaxelivraison = false
        
                        ped = GetPlayerPed(-1)
                        playerCoords = GetEntityCoords(ped)
                        nbMission = math.random(1, 13)
                        px = position[nbMission].x
                        py = position[nbMission].y
                        pz = position[nbMission].z
                        distance = round(GetDistanceBetweenCoords(playerCoords, px,py,pz))
        
                        paie = distance * coefflouze
        
                        StartBliper(position,nbMission)
                      end
                  else
                    ShowNotification("~r~Vous avez besoin d'un sac pour effectuer la livraison")
                  end
              end	
          else
            if IsControlJustPressed(1,38) then
              notif2 = true
              posibilidad = math.random(1, 100)
              afaitunplatmin = true
              _TriggerServerEvent("axeBrinks:itemrm")
              nbaxelivraison = nbaxelivraison - 1
              ShowNotification("~g~Voici votre argent, merci au revoir ! ~w~" .. paie .. "~b~ $")
              _TriggerServerEvent("axeBrinks:paie", paie)
              if (posibilidad > 70) and (posibilidad < 90) then

                ShowNotification("~g~Un petit pourboire : ~w~" .. pourboire .. "~b~ $")

                _TriggerServerEvent("axeBrinks:pourboire", pourboire)

              end
              RemoveBlip(Blip)
              Wait(250)
              if nbaxelivraison == 0 then
                isToHouse = false
                isToaxelivraison = true
              else
                isToHouse = true
                isToaxelivraison = false

                ped = GetPlayerPed(-1)
                playerCoords = GetEntityCoords(ped)
                nbMission = math.random(1, 13)
                px = position[nbMission].x
                py = position[nbMission].y
                pz = position[nbMission].z
                distance = round(GetDistanceBetweenCoords(playerCoords, px,py,pz))

                paie = distance * coefflouze

                StartBliper(position,nbMission)
              end
          end
          end	

        end

      end

      if IsEntityDead(GetPlayerPed(-1)) then

        isInJobLIVR = false
        livr = 0
        isToHouse = false
        isToaxelivraison = false

        paie = 0
        px = 0
        py = 0
        pz = 0
        RemoveBlip(Blip)

      end
    Wait(WaitBro)
  end
end)



CreateThread(function() 
  while true do

    local Waiting = 350

    if isInJobLIVR == true then

      Waiting = 0

      DrawMarker(22, Config.Job.StopMission, 0, 0, 0, 90, 0, 0, 0.3, 0.3, 0.3,255,215,0, 255, 255, 255, 255, 255)

      if GetDistanceBetweenCoords(Config.Job.StopMission, GetEntityCoords(GetPlayerPed(-1),true)) < 3 then
        ShowHelpNotification("Appuyez sur ~INPUT_CONTEXT~ pour arrêter la livraison",0,1,0.5,0.8,0.6,255,215,0,255,255,255,255)

        if IsControlJustPressed(1,38) then

          StopMission()

          if IsInVehicle() then

            if afaitunplatmin == true then

              local vehicleu = GetVehiclePedIsIn(GetPlayerPed(-1), false)

              SetEntityAsMissionEntity( vehicleu, true, true )
              deleteCar( vehicleu )

              ShowNotification("~b~Merci d'avoir travaillé, bonne journée, voici votre paie.")

              _TriggerServerEvent("axeBrinks:paiefinale")

              SetWaypointOff()

              afaitunplatmin = false

            else

              local vehicleu = GetVehiclePedIsIn(GetPlayerPed(-1), false)

              SetEntityAsMissionEntity( vehicleu, true, true )
              deleteCar( vehicleu )

              ShowNotification("~r~Vous avez été moins productif, mais merci quand même, bonne journée")

            end
          else
            ShowNotification("~r~Tu n'a pas ton vehicule de service ! Tu perd 300 $")
            _TriggerServerEvent("axeBrinks:paiemoins")
          end
        end
      end
    end
    Wait(Waiting)
  end
end)
