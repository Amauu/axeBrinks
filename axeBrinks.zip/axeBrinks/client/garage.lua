CreateThread(function()
	for _, v in pairs(Config.NPC) do
		local hash = GetHashKey(v.hash)
		while not HasModelLoaded(hash) do
		RequestModel(hash)
		Wait(20)
		end
		ped2 = CreatePed("PED_TYPE_CIVFEMALE", v.hash, v.position, false, true)
        TaskStartScenarioInPlace(ped2, 'WORLD_HUMAN_CLIPBOARD_FACILITY', 0, true)
		SetBlockingOfNonTemporaryEvents(ped2, true)
		FreezeEntityPosition(ped2, true)
		SetEntityInvincible(ped2, true)
	end
end)

function RangeTonVeh(vehicle)
    local playerPed = GetPlayerPed(-1)
    local vehicle = GetVehiclePedIsIn(playerPed, false)
    local props = ESX.Game.GetVehicleProperties(vehicle)
    local current = GetPlayersLastVehicle(GetPlayerPed(-1), true)
    local engineHealth = GetVehicleEngineHealth(current)

    if IsPedInAnyVehicle(GetPlayerPed(-1), true) then 
        if engineHealth < 890 then
            ShowNotification("Votre véhicule est trop abimé, vous ne pouvez pas le ranger.")
        else
            DoScreenFadeOut(1500)
            Citizen.Wait(1500)
            ESX.Game.DeleteVehicle(vehicle)
            DoScreenFadeIn(1500)
            ShowNotification("~g~Le véhicule a été rangé dans le garage")
        end
    end
end

function SpawnBrinksCar(car)
    local ped = PlayerPedId()
    local car = GetHashKey(car)
    RequestModel(car) while not HasModelLoaded(car) do Citizen.Wait(10) end
    local pos = GetEntityCoords(ped) 
    local vehicle = CreateVehicle(car, Config.Job.SpawnCar, true, false)
    SetEntityAsMissionEntity(vehicle, true, true)
    DoScreenFadeOut(1500)
    Citizen.Wait(1500)
    DoScreenFadeIn(1500)
    SetPedIntoVehicle(ped,vehicle,-1)
end

function GarageBrinks()
    local Brinks = RageUI.CreateMenu("", "Menu Intéraction")
        RageUI.Visible(Brinks, not RageUI.Visible(Brinks))
            while Brinks do
            Citizen.Wait(0)
            RageUI.IsVisible(Brinks, true, true, true, function()

                RageUI.Separator("↓ ~y~Gestion des Véhicules~s~↓")

                RageUI.Line()

                RageUI.ButtonWithStyle("→ Sortir un Brinks", "Véhicule de livraison", {RightLabel = ""},true, function(Hovered, Active, Selected)
                    if (Selected) then  
                        SpawnBrinksCar("stockade")
                        RageUI.CloseAll()
                    end
                end)

                RageUI.ButtonWithStyle("→ Sortir une Revolter", "Véhicule de renfort", {RightLabel = ""},true, function(Hovered, Active, Selected)
                    if (Selected) then  
                        SpawnBrinksCar("revolter")
                        RageUI.CloseAll()
                    end
                end)

            end, function()
            end)

            if not RageUI.Visible(Brinks) then
            Brinks = RMenu:DeleteType(Brinks, true)
            FreezeEntityPosition(PlayerPedId(), false)
        end
    end
end
