function ApplySkin(infos)
	TriggerEvent('skinchanger:getSkin', function(skin)
		local uniformObject

		if skin.sex == 0 then
			uniformObject = infos.variations.male
		else
			uniformObject = infos.variations.female
		end

		if uniformObject then
			TriggerEvent('skinchanger:loadClothes', skin, uniformObject)
		end

		infos.onEquip()
	end)
end


function VestiaireBrinks()
    local VestiaireBrinks = RageUI.CreateMenu("", "Menu Intéraction..")
        RageUI.Visible(VestiaireBrinks, not RageUI.Visible(VestiaireBrinks))
            while VestiaireBrinks do
            Citizen.Wait(0)
            RageUI.IsVisible(VestiaireBrinks, true, true, true, function()
                FreezeEntityPosition(PlayerPedId(), true)

                RageUI.Separator("↓ ~y~Tenues Disponibles~s~ ↓")

                RageUI.Line()

                for index,infos in pairs(Config.Tenue.specials) do
                    RageUI.ButtonWithStyle(infos.label,nil, {RightBadge = RageUI.BadgeStyle.Clothes}, ESX.PlayerData.job.grade >= infos.minimum_grade, function(_,_,s)
                        if s then
                            local lib, anim = 'clothingtie', 'try_tie_neutral_a'
                            ESX.Streaming.RequestAnimDict(lib, function()
                                TaskPlayAnim(PlayerPedId(), lib, anim, 8.0, -8.0, -1, 0, 0, false, false, false)
                            end)
                            Citizen.Wait(1000)
                            ClearPedTasks(PlayerPedId())
                            ApplySkin(infos)
                            RageUI.CloseAll()
                        end
                    end)
                end

            end, function()
            end)

            if not RageUI.Visible(VestiaireBrinks) then
            VestiaireBrinks = RMenu:DeleteType("VestiaireBrinks", true)
            FreezeEntityPosition(PlayerPedId(), false)
        end
    end
end
