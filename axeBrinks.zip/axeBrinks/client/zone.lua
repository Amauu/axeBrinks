CreateThread(function()
    while true do
        local Sleeping = 500

        local plyPos = GetEntityCoords(PlayerPedId())

        local distance_boss = #(plyPos-Config.Job.Boss)
        local distance_coffre = #(plyPos-Config.Job.Coffre)
        local distance_garage = #(plyPos-Config.Job.Garage)
        local distance_ranger = #(plyPos-Config.Job.RangerVeh)
        local distance_vestiaire = #(plyPos-Config.Job.Vestiaire)
        local distance_resell = #(plyPos-Config.Robbery.Resell)

        if ESX.PlayerData.job and ESX.PlayerData.job.name == "brinks" and ESX.PlayerData.job.grade_name == 'boss' then

            if distance_boss <= 10 then
                Sleeping = 0
                DrawMarker(22, Config.Job.Boss, 0.0, 0.0, 0.0, 0.0,0.0,0.0, 0.3, 0.3, 0.3, 255, 215, 0 , 255, true, true, p19, true)
            end

            if distance_boss <= 1.5 then
                Sleeping = 0
                ESX.ShowHelpNotification("Appuyez sur ~INPUT_CONTEXT~ pour ouvrir →→ Actions Patron")
                if IsControlJustPressed(1,51) then
                    RefreshBrinksMoney()
                    MenuBossBrinks()
                end
            end

        end


        if ESX.PlayerData.job and ESX.PlayerData.job.name == "brinks" then

            if distance_vestiaire <= 10.0 then
                Sleeping = 0
                DrawMarker(22, Config.Job.Vestiaire, 0.0, 0.0, 0.0, 0.0,0.0,0.0, 0.3, 0.3, 0.3, 255, 215, 0 , 255, true, true, p19, true)
            end

            if distance_vestiaire <= 1.0 then
                Sleeping = 0
                ESX.ShowHelpNotification("Appuyez sur ~INPUT_CONTEXT~ pour ouvrir le vestiaire")
                if IsControlJustPressed(1,51) then
                    VestiaireBrinks()
                end
            end

            if distance_coffre <= 10.0 then
                Sleeping = 0
                DrawMarker(22, Config.Job.Coffre, 0.0, 0.0, 0.0, 0.0,0.0,0.0, 0.3, 0.3, 0.3, 255, 215, 0 , 255,255,255, false, true, p19, true)
            end
        
            if distance_coffre <= 1.0 then
                Sleeping = 0
                ESX.ShowHelpNotification("Appuyez sur ~INPUT_CONTEXT~ pour ouvrir le coffre")
                if IsControlJustPressed(1,51) then
                    CoffreBrinks()
                end
            end

            if distance_garage <= 1.5 then
                Sleeping = 0
                ESX.ShowHelpNotification("Appuyez sur ~INPUT_CONTEXT~ pour ouvrir le garage")
                if IsControlJustPressed(1,51) then
                    FreezeEntityPosition(PlayerPedId(), true)
                    RageUI.Text({message = "[~b~Vous~w~] Salut Remy !",time_display = 1500})
                    Wait(2000)
                    RageUI.Text({message = "[~o~Remy~w~] Salut tu as besoin de quoi ?",time_display = 1500})
                    Wait(2000)
                    RageUI.Text({message = "[~b~Vous~w~] Il me faut un véhicule de fonction",time_display = 1500})
                    Wait(2000)
                    RageUI.Text({message = "[~o~Remy~w~] Ok je regarde si j'en ai encore en stock...",time_display = 1500})
                    Wait(2000)
                    RageUI.Text({message = "[~o~Remy~w~] Oui c'est bon tiens regarde ce qu'il me reste !",time_display = 1500})
                    Wait(2000)
                    RageUI.Text({message = "[~b~Vous~w~] Merci !",time_display = 1500})
                    Wait(2000)
                    GarageBrinks()
                end
            end

            if distance_ranger <= 4.0 then
                Sleeping = 0
                if IsPedInAnyVehicle(GetPlayerPed(-1), false) then
                    DrawMarker(22, Config.Job.RangerVeh, 0.0, 0.0, 0.0, 0.0,0.0,0.0, 0.3, 0.3, 0.3, 255, 215, 0 , 255,255,255, true, true, p19, true)
                    ESX.ShowHelpNotification("Appuyez sur ~INPUT_CONTEXT~ pour rendre votre véhicule à Remy")
                    if IsControlJustPressed(1,51) then
                        DoScreenFadeOut(1500)
                        Citizen.Wait(1500)
                        DoScreenFadeIn(1500)
                        RangeTonVeh()
                    end
                end
            end

        end

        if distance_resell <= 1.5 then
            Sleeping = 0
            ESX.ShowHelpNotification("Appuyez sur ~INPUT_CONTEXT~ pour parler au monsieur")
            if IsControlJustPressed(1,51) then
                ResellMenu()
            end
        end

		Citizen.Wait(Sleeping)
	end
end)