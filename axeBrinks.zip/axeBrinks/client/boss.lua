function RefreshBrinksMoney()
    if ESX.PlayerData.job ~= nil and ESX.PlayerData.job.grade_name == 'boss' then
        ESX.TriggerServerCallback('axeBrinks:getSocietyMoney', function(money)
            UpBrinksMoney(money)
        end, ESX.PlayerData.job.name)
    end
end

function UpBrinksMoney(money)
    BrinksAccountMoney = ESX.Math.GroupDigits(money)
end

function MenuBossBrinks()
    local main = RageUI.CreateMenu("", "Actions Patron")
    FreezeEntityPosition(PlayerPedId(), true)
        RageUI.Visible(main, not RageUI.Visible(main))
            while main do
            Citizen.Wait(0)
            RageUI.IsVisible(main, true, true, true, function()

            RageUI.Line()
            if BrinksAccountMoney ~= nil then
                RageUI.Separator("~b~Compte de l'enteprise ~s~→ ~g~"..BrinksAccountMoney.."$")
            end
            RageUI.Line()

            RageUI.ButtonWithStyle("→ Retirer de l'argent",nil, {}, not cooldown, function(Hovered, Active, Selected)
                if Selected then
                    local amount = KeyboardInput("Montant", "", 10)
                    amount = tonumber(amount)
                    if amount == nil then
                        RageUI.Popup({message = "[~r~Problème~s~]\nMontant invalide"})
                    else
                        _TriggerServerEvent("axeBrinks:retraitentreprise", amount)
                        RefreshBrinksMoney()
                    end
                    cooldownMenu(2000)
                end
            end)

            RageUI.ButtonWithStyle("→ Déposer de l'argent",nil, {}, not cooldown, function(Hovered, Active, Selected)
                if Selected then
                    local amount = KeyboardInput("Montant", "", 10)
                    amount = tonumber(amount)
                    if amount == nil then
                        RageUI.Popup({message = "[~r~Problème~s~]\nMontant invalide"})
                    else
                        _TriggerServerEvent("axeBrinks:depotentreprise", amount)
                        RefreshBrinksMoney()
                    end
                    cooldownMenu(2000)
                end
            end) 

            RageUI.ButtonWithStyle("→ Recruter", nil, {}, not cooldown, function(Hovered, Active, Selected)
                if (Selected) then   
                    local closestPlayer, closestDistance = ESX.Game.GetClosestPlayer()
                    if closestPlayer ~= -1 and closestDistance <= 3.0 then
                        _TriggerServerEvent('axeBrinks:recruter', GetPlayerServerId(closestPlayer))
                    else
                        RageUI.Popup({message = "[~r~Problème~s~]\nAucun joueur à proximité"})
                    end 
                    cooldownMenu(2000)
                end
            end)

                RageUI.ButtonWithStyle("→ Promouvoir", nil, {}, not cooldown, function(Hovered, Active, Selected)
                if (Selected) then   
                    local closestPlayer, closestDistance = ESX.Game.GetClosestPlayer()
                    if closestPlayer ~= -1 and closestDistance <= 3.0 then
                        _TriggerServerEvent('axeBrinks:promouvoir', GetPlayerServerId(closestPlayer))
                    else
                        RageUI.Popup({message = "[~r~Problème~s~]\nAucun joueur à proximité"})
                    end 
                end
            end)

                RageUI.ButtonWithStyle("→ Rétrograder", nil, {}, not cooldown, function(Hovered, Active, Selected)
                if (Selected) then   
                    local closestPlayer, closestDistance = ESX.Game.GetClosestPlayer()
                    if closestPlayer ~= -1 and closestDistance <= 3.0 then
                        _TriggerServerEvent('axeBrinks:descendre', GetPlayerServerId(closestPlayer))
                    else
                        RageUI.Popup({message = "[~r~Problème~s~]\nAucun joueur à proximité"})
                    end 
                    cooldownMenu(2000)
                end
            end)

                RageUI.ButtonWithStyle("→ Virer", nil, {}, not cooldown, function(Hovered, Active, Selected)
                if (Selected) then   
                    local closestPlayer, closestDistance = ESX.Game.GetClosestPlayer()
                    if closestPlayer ~= -1 and closestDistance <= 3.0 then
                        _TriggerServerEvent('axeBrinks:virer', GetPlayerServerId(closestPlayer))
                    else
                        RageUI.Popup({message = "[~r~Problème~s~]\nAucun joueur à proximité"})
                    end 
                    cooldownMenu(2000)
                end
            end)

            RageUI.Line()

            end, function()
            end)

            if not RageUI.Visible(main) then
            main = RMenu:DeleteType(main, true)
            FreezeEntityPosition(PlayerPedId(), false)
        end
    end
end