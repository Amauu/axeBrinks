
local currentToken = ""

function _TriggerServerEvent(eventName, ...)
    TriggerServerEvent(eventName, currentToken, ...)
end

RegisterNetEvent("axeBrinks:OnRequestToken")
AddEventHandler("axeBrinks:OnRequestToken", function(newToken)
    currentToken = newToken
end)

CreateThread(function()
    TriggerServerEvent("axeBrinks:RequestToken")
end)

ShowHelpNotification = function(text)
	AddTextEntry("HelpNotification", text)
    DisplayHelpTextThisFrame("HelpNotification", false)
end

ShowNotification = function(text)
    SetNotificationTextEntry("STRING")
    AddTextComponentString(text)
    DrawNotification(false, false)
end

cooldownMenu = function(time)
    cooldown = true
    Citizen.SetTimeout(time,function()
        cooldown = false
    end)
end

CreateThread(function()
    local blip = AddBlipForCoord(Config.Job.Blips.Zone)

    SetBlipSprite (blip, Config.Job.Blips.Sprite)
    SetBlipScale  (blip, Config.Job.Blips.Scale)
    SetBlipColour (blip, Config.Job.Blips.Color)
    SetBlipAsShortRange(blip, true)

    BeginTextCommandSetBlipName('STRING')
    AddTextComponentSubstringPlayerName(Config.Job.Blips.Name)
    EndTextCommandSetBlipName(blip)
end)


function MenuBrinks()
    local xIndexList = 1
    local F6Brinks = RageUI.CreateMenu("", "Tablette Brink's")
    local label = "~r~Service Inactif~s~"
    RageUI.Visible(F6Brinks, not RageUI.Visible(F6Brinks))
    while F6Brinks do
        Citizen.Wait(0)
            RageUI.IsVisible(F6Brinks, true, true, true, function()

                RageUI.Separator("↓ "..label.." ↓")
                if onservice then
                RageUI.Separator("Votre grade → ~y~"..ESX.PlayerData.job.grade_label.." ~s~")
                end
                RageUI.Line()

                RageUI.Checkbox("Activer sa tablette",nil, service,{},function(Hovered,Ative,Selected,Checked)
                    if Selected then
                        service = Checked
                        if Checked then
                            onservice = true
                            label = "~g~Service Actif~s~"
                        else
                            onservice = false
                            label = "~r~Service Inactif~s~"
                        end
                    end
                end)

                RageUI.Line()
    
                if onservice then


                    RageUI.ButtonWithStyle("Faire une facture",nil, {RightLabel = "→"}, not cooldown, function(_,_,s)
                        local player, distance = ESX.Game.GetClosestPlayer()
                        if s then
                            local raison = ""
                            local montant = 0
                            AddTextEntry("FMMC_MPM_NA", "Objet de la facture")
                            DisplayOnscreenKeyboard(1, "FMMC_MPM_NA", "Donnez le motif de la facture :", "", "", "", "", 30)
                            while (UpdateOnscreenKeyboard() == 0) do
                                DisableAllControlActions(0)
                                Wait(0)
                            end
                            if (GetOnscreenKeyboardResult()) then
                                local result = GetOnscreenKeyboardResult()
                                if result then
                                    raison = result
                                    result = nil
                                    AddTextEntry("FMMC_MPM_NA", "Montant de la facture")
                                    DisplayOnscreenKeyboard(1, "FMMC_MPM_NA", "Indiquez le montant de la facture :", "", "", "", "", 30)
                                    while (UpdateOnscreenKeyboard() == 0) do
                                        DisableAllControlActions(0)
                                        Wait(0)
                                    end
                                    if (GetOnscreenKeyboardResult()) then
                                        result = GetOnscreenKeyboardResult()
                                        if result then
                                            montant = result
                                            result = nil
                                            if player ~= -1 and distance <= 3.0 then
                                                _TriggerServerEvent('esx_billing:sendBill', GetPlayerServerId(player), 'society_brinks', ('brinks'), montant)
                                                TriggerEvent('esx:showAdvancedNotification', 'Fl~g~ee~s~ca ~g~Bank', 'Facture envoyée : ', 'Vous avez envoyé une facture d\'un montant de : ~g~'..montant.. '$ ~s~pour cette raison : ~b~' ..raison.. '', 'CHAR_BANK_FLEECA', 9)
                                            else
                                                ShowNotification("~r~Probleme~s~: Aucuns joueurs proche")
                                            end
                                        end
                                    end
                                end
                            end
                        end
                    end)
                    RageUI.List("Annonce", {"~g~Ouvert~s~", "~r~Fermé~s~", "~o~Perso~s~"}, xIndexList, nil, {}, not cooldown, {
                        onListChange = function(Index, Item)
                            xIndexList = Index
                        end,
                        onSelected = function(Index,Item)
                            if xIndexList == 1 then
                                _TriggerServerEvent("axeBrinks:Annonce", true, false)
                                cooldownMenu(1000)
                            elseif xIndexList == 2 then
                                _TriggerServerEvent("axeBrinks:Annonce", false, true)
                                cooldownMenu(1000)
                            elseif xIndexList == 3 then
                                local msg = KeyboardInput("Message", nil, 100)
                                _TriggerServerEvent("axeBrinks:Perso", msg)
                                cooldownMenu(1000)
                            end
                        end
                    })

                    RageUI.Checkbox("Commencer les livraisons",nil, MissionJob, {},function(Hovered,Ative,Selected,Checked)
                        if Selected then
                            MissionJob = Checked
                            if Checked then
                                if IsInAuthorizedVehicle() then
                                    OnMission = true
                                    StartMission()
                                    RageUI.Popup({message = "~g~Vous commencez vos missions, bonne chance."})
                                else
                                    RageUI.Popup({message = "~r~Tu dois être dans ton camion de livraison !"})
                                    MissionJob = false
                                end
                            else
                                MissionJob = true
                                RageUI.Popup({message = "~r~Vous devez rentrer au dépôt pour arrêter votre mission.\nPoint GPS pour rentrer au dépôt mis"})
                                SetNewWaypoint(Config.Job.StopMission)
                            end
                        end
                    end)

                end
            
        end, function() 
        end)

        if not RageUI.Visible(AmmuFarm) then
            AmmuFarm = RMenu:DeleteType("AmmuFarm", true)
        end
    end
end


Keys.Register('F6', 'brinks', 'Ouvrir le Menu brinks', function()
	if ESX.PlayerData.job and ESX.PlayerData.job.name == 'brinks' then
    	MenuBrinks()
	end
end)